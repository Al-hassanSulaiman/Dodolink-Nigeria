DodoLink NG — Expo source backup

The Expo project root is artifacts/dodolink-ng/. It contains package.json,
app.json, eas.json, the app source, plugins, assets, tests, and project scripts.
The one local workspace package it imports is included at lib/api-client-react/.
A focused pnpm workspace file retains the source workspace's version catalog.

This is a source-only snapshot, not an IPA. It excludes node_modules, generated
Expo/web builds, the ignored generated ios/ and android/ folders, local package
manager settings, credential files, and signed app binaries. A full workspace
lockfile is not included because unrelated monorepo projects are not included.
