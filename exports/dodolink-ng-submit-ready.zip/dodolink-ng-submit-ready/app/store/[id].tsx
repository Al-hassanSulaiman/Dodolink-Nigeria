import { useState } from 'react';
import { StyleSheet, View, Text, ScrollView, RefreshControl, Pressable } from 'react-native';
import { showAlert } from '@/utils/alerts';
import { isStoreNameAlreadyExistsError } from '@/utils/storeErrors';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import {
  useGetStore,
  useListStoreProducts,
  useListStoreReviews,
  useCreateReview,
  useUpdateStore,
  useStartConversation,
  getListConversationsQueryKey,
  getGetStoreQueryKey,
  getListStoresQueryKey,
  getListStoreReviewsQueryKey,
  getListStoreProductsQueryKey,
} from '@workspace/api-client-react';
import { useColors } from '@/hooks/useColors';
import { useUserIdentity } from '@/hooks/useUserIdentity';
import { LoadingScreen } from '@/components/Loading';
import { StoreAvatar } from '@/components/StoreAvatar';
import { ProductCard } from '@/components/ProductCard';
import { StarRating } from '@/components/StarRating';
import { EmptyState } from '@/components/EmptyState';
import { Feather } from '@expo/vector-icons';
import { Input, Button } from '@/components/ui';
import { useQueryClient } from '@tanstack/react-query';

export default function StoreScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const storeId = parseInt(id, 10);
  const colors = useColors();
  const { userId, userName } = useUserIdentity();
  const queryClient = useQueryClient();

  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [chatError, setChatError] = useState('');

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editCacNumber, setEditCacNumber] = useState('');

  const { data: store, isLoading: storeLoading, isError: storeError, refetch: refetchStore } = useGetStore(storeId, {
    query: { enabled: !!storeId, queryKey: getGetStoreQueryKey(storeId) }
  });

  const { data: products } = useListStoreProducts(storeId, {
    query: { enabled: !!storeId, queryKey: getListStoreProductsQueryKey(storeId) }
  });

  const { data: reviews } = useListStoreReviews(storeId, {
    query: { enabled: !!storeId, queryKey: getListStoreReviewsQueryKey(storeId) }
  });

  const createReview = useCreateReview({
    mutation: {
      onSuccess: () => {
        setRating(0);
        setComment('');
        refetchStore();
        queryClient.invalidateQueries({ queryKey: getListStoreReviewsQueryKey(storeId) });
      }
    }
  });

  const updateStore = useUpdateStore({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStoresQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetStoreQueryKey(storeId) });
        setIsEditing(false);
      },
      onError: (error) => {
        if (isStoreNameAlreadyExistsError(error)) {
          showAlert(
            'Store name already exists',
            'A verified store is already using this name. Please choose another store name.',
          );
          return;
        }
        showAlert('Save failed', 'Could not update the store. Please try again.');
      }
    }
  });

  const isOwner = !!userId && !!store && store.ownerUserId === userId;
  const detailsLocked = !!store?.detailsLockedByAdmin;
  const startConversation = useStartConversation({
    mutation: {
      onSuccess: (conversation) => {
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        router.push(`/chat/${conversation.id}`);
      },
      onError: () => {
        setChatError('Could not open the chat. Check your connection and try again.');
      },
    },
  });
  const handleChat = () => {
    if (!store || isOwner || startConversation.isPending) return;
    setChatError('');
    if (!userId) {
      router.push({ pathname: '/(auth)/sign-in', params: { returnTo: `/store/${storeId}` } });
      return;
    }
    startConversation.mutate({ data: {
      customerId: userId,
      customerName: userName,
      storeId,
    } });
  };

  const handleStartEdit = () => {
    if (!store) return;
    setEditName(store.name);
    setEditDescription(store.description);
    setEditLocation(store.location);
    setEditCategory(store.category);
    setEditPhone(store.phone);
    setEditCacNumber(store.cacNumber ?? '');
    setIsEditing(true);
  };

  const handleSave = () => {
    updateStore.mutate({
      storeId,
      data: {
        // Name and location are managed by the admin once locked
        ...(detailsLocked
          ? {}
          : {
              name: editName.trim() || store!.name,
              location: editLocation.trim(),
            }),
        description: editDescription.trim(),
        category: editCategory.trim(),
        phone: editPhone.trim(),
        cacNumber: editCacNumber.trim() || null,
      }
    });
  };

  const handleSubmitReview = () => {
    if (!userId) {
      router.push({ pathname: '/(auth)/sign-in', params: { returnTo: `/store/${storeId}` } });
      return;
    }
    if (!rating || !userId || !userName) return;
    createReview.mutate({ storeId, data: {
      rating,
      comment,
      reviewerId: userId,
      reviewerName: userName
    }});
  };

  const onRefresh = () => { refetchStore(); };

  if (storeLoading && !store) return <LoadingScreen message="Loading store..." />;
  if (storeError && !store) return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, backgroundColor: colors.background }}>
      <Feather name="wifi-off" size={48} color={colors.mutedForeground} />
      <Text style={{ fontFamily: 'Inter_600SemiBold', fontSize: 18, color: colors.foreground, marginTop: 16, textAlign: 'center' }}>Couldn't load this store</Text>
      <Text style={{ fontFamily: 'Inter_400Regular', fontSize: 14, color: colors.mutedForeground, marginTop: 8, textAlign: 'center' }}>Check your connection and try again.</Text>
      <Pressable onPress={() => refetchStore()} style={{ marginTop: 20, paddingHorizontal: 24, paddingVertical: 10, backgroundColor: colors.primary, borderRadius: 20 }}>
        <Text style={{ fontFamily: 'Inter_600SemiBold', fontSize: 14, color: colors.primaryForeground }}>Try again</Text>
      </Pressable>
    </View>
  );
  if (!store) return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, backgroundColor: colors.background }}>
      <Feather name="alert-circle" size={48} color={colors.mutedForeground} />
      <Text style={{ fontFamily: 'Inter_600SemiBold', fontSize: 18, color: colors.foreground, marginTop: 16, textAlign: 'center' }}>Store not found</Text>
      <Text style={{ fontFamily: 'Inter_400Regular', fontSize: 14, color: colors.mutedForeground, marginTop: 8, textAlign: 'center' }}>This store may have been removed.</Text>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen
        options={{
          title: isEditing ? 'Edit Store' : store.name,
          headerRight: isOwner ? () => (
            isEditing ? (
              <View style={styles.headerButtons}>
                <Pressable onPress={() => setIsEditing(false)} hitSlop={8} style={styles.headerBtn}>
                  <Feather name="x" size={20} color={colors.mutedForeground} />
                </Pressable>
                <Pressable onPress={handleSave} hitSlop={8} style={styles.headerBtn} disabled={updateStore.isPending}>
                  <Feather name="check" size={20} color={colors.primary} />
                </Pressable>
              </View>
            ) : (
              <Pressable onPress={handleStartEdit} hitSlop={8} style={styles.headerBtn}>
                <Feather name="edit-2" size={18} color={colors.mutedForeground} />
              </Pressable>
            )
          ) : undefined,
        }}
      />
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={storeLoading} onRefresh={onRefresh} />}
      >
        <View style={[styles.banner, { backgroundColor: colors.primary }]} />

        <View style={styles.header}>
          <View style={[styles.avatarContainer, { borderColor: colors.background }]}>
            <StoreAvatar store={store} size={80} editable={isOwner} />
          </View>

          <View style={styles.headerInfo}>
            {isEditing && !detailsLocked ? (
              <Input
                value={editName}
                onChangeText={setEditName}
                placeholder="Store name"
                style={styles.editNameInput}
              />
            ) : (
              <View style={styles.nameRow}>
                <Text style={[styles.name, { color: colors.foreground }]}>
                  {store.name}
                  {isEditing && detailsLocked ? (
                    <Text style={{ color: colors.mutedForeground }}> <Feather name="lock" size={14} /></Text>
                  ) : null}
                </Text>
                {store.verificationStatus === 'verified' && !isEditing && (
                  <View style={[styles.verifiedBadge, { backgroundColor: colors.primary }]}>
                    <Feather name="check-circle" size={11} color="#fff" />
                    <Text style={styles.verifiedBadgeText}>Verified</Text>
                  </View>
                )}
              </View>
            )}
            <View style={styles.statsRow}>
              <StarRating rating={store.avgRating || 0} size={14} />
              <Text style={[styles.reviewsCount, { color: colors.mutedForeground }]}>
                ({store.totalReviews} reviews)
              </Text>
            </View>
            {isEditing && !detailsLocked ? (
              <Input
                value={editLocation}
                onChangeText={setEditLocation}
                placeholder="Location"
                style={styles.editInlineInput}
              />
            ) : (
              <Text style={[styles.location, { color: colors.mutedForeground }]}>
                <Feather name="map-pin" size={12} /> {store.location}
                {isEditing && detailsLocked ? (
                  <Text> <Feather name="lock" size={12} /></Text>
                ) : null}
              </Text>
            )}
          </View>
        </View>

        {!isOwner && !isEditing && (
          <View style={styles.section}>
            <Button
              title={startConversation.isPending ? 'Opening chat…' : 'Chat with seller'}
              onPress={handleChat}
              disabled={startConversation.isPending}
            />
            {!!chatError && <Text accessibilityRole="alert" style={{ color: colors.destructive, marginTop: 8 }}>{chatError}</Text>}
          </View>
        )}

        {isEditing ? (
          <View style={styles.section}>
            {detailsLocked ? (
              <View style={[styles.lockedNotice, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="lock" size={14} color={colors.mutedForeground} />
                <Text style={[styles.lockedNoticeText, { color: colors.mutedForeground }]}>
                  Your store name and location were set by Dodolink admin and can no longer be changed.
                </Text>
              </View>
            ) : null}
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>Description</Text>
            <Input
              value={editDescription}
              onChangeText={setEditDescription}
              placeholder="Tell customers about your store..."
              multiline
              style={styles.textArea}
            />
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>Category</Text>
            <Input
              value={editCategory}
              onChangeText={setEditCategory}
              placeholder="e.g. Food & Drinks, Fashion..."
            />
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>Phone</Text>
            <Input
              value={editPhone}
              onChangeText={setEditPhone}
              placeholder="+234..."
              keyboardType="phone-pad"
            />
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>CAC Registration Number (optional)</Text>
            <Input
              value={editCacNumber}
              onChangeText={setEditCacNumber}
              placeholder="e.g. RC-1234567"
              autoCapitalize="characters"
            />
            <Button
              title={updateStore.isPending ? 'Saving...' : 'Save Changes'}
              onPress={handleSave}
              disabled={updateStore.isPending}
              style={styles.saveBtn}
            />
          </View>
        ) : (
          <View style={styles.section}>
            <Text style={[styles.description, { color: colors.foreground }]}>{store.description}</Text>
            {store.cacNumber ? (
              <View style={[styles.cacRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
                <Feather name="shield" size={14} color={colors.primary} />
                <Text style={[styles.cacLabel, { color: colors.mutedForeground }]}>CAC Reg:</Text>
                <Text style={[styles.cacValue, { color: colors.foreground }]}>{store.cacNumber}</Text>
              </View>
            ) : null}
          </View>
        )}

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Products</Text>
          {products && products.length > 0 ? (
            <View style={styles.grid}>
              {products.map(product => (
                <View key={product.id} style={styles.gridItem}>
                  <ProductCard product={product} />
                </View>
              ))}
            </View>
          ) : (
            <EmptyState icon="box" title="No products" description="This store hasn't added any products yet." />
          )}
        </View>

        {!isEditing && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Reviews</Text>

            {store.verificationStatus !== 'verified' ? (
              <View style={[styles.unverifiedNotice, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="lock" size={16} color={colors.mutedForeground} />
                <Text style={[styles.unverifiedText, { color: colors.mutedForeground }]}>
                  Reviews are only available for verified stores.
                </Text>
              </View>
            ) : (
              <>
                {!isOwner && (
                  <View style={[styles.reviewForm, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <Text style={[styles.formTitle, { color: colors.foreground }]}>Leave a Review</Text>
                    <StarRating rating={rating} onRatingChange={setRating} size={24} showText={false} />
                    <Input
                      placeholder="Write your comment..."
                      value={comment}
                      onChangeText={setComment}
                      multiline
                      style={styles.reviewInput}
                    />
                    <Button
                      title={createReview.isPending ? 'Submitting...' : 'Submit Review'}
                      onPress={handleSubmitReview}
                      disabled={rating === 0 || createReview.isPending}
                    />
                  </View>
                )}

                {reviews && reviews.length > 0 ? (
                  reviews.map(review => (
                    <View key={review.id} style={[styles.reviewItem, { borderBottomColor: colors.border }]}>
                      <View style={styles.reviewHeader}>
                        <Text style={[styles.reviewerName, { color: colors.foreground }]}>{review.reviewerName}</Text>
                        <StarRating rating={review.rating} size={12} showText={false} />
                      </View>
                      {review.comment ? (
                        <Text style={[styles.reviewComment, { color: colors.foreground }]}>{review.comment}</Text>
                      ) : null}
                    </View>
                  ))
                ) : (
                  <Text style={[styles.noReviews, { color: colors.mutedForeground }]}>No reviews yet.</Text>
                )}
              </>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingBottom: 40 },
  banner: { height: 120, width: '100%' },
  header: {
    paddingHorizontal: 16,
    flexDirection: 'row',
    marginTop: -40,
    marginBottom: 16,
  },
  avatarContainer: {
    width: 88,
    height: 88,
    borderRadius: 44,
    borderWidth: 4,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatar: {
    width: '100%',
    height: '100%',
  },
  headerInfo: {
    flex: 1,
    marginLeft: 16,
    justifyContent: 'flex-end',
    paddingBottom: 4,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 4,
  },
  name: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  verifiedBadgeText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
    color: '#fff',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  reviewsCount: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    marginLeft: 8,
  },
  location: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  description: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    lineHeight: 24,
  },
  sectionTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    marginBottom: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -8,
  },
  gridItem: {
    width: '50%',
    paddingHorizontal: 8,
  },
  reviewForm: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 24,
  },
  formTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    marginBottom: 12,
  },
  reviewInput: {
    height: 80,
    marginTop: 12,
    marginBottom: 12,
    textAlignVertical: 'top',
  },
  reviewItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  reviewerName: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
  },
  reviewComment: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 22,
  },
  noReviews: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    textAlign: 'center',
    marginTop: 16,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerBtn: {
    padding: 4,
  },
  editNameInput: {
    marginBottom: 4,
    fontFamily: 'Inter_700Bold',
    fontSize: 18,
  },
  editInlineInput: {
    marginTop: 4,
    fontSize: 14,
  },
  fieldLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
    marginTop: 12,
    marginBottom: 4,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  saveBtn: {
    marginTop: 20,
  },
  lockedNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 8,
  },
  lockedNoticeText: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 17,
  },
  unverifiedNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
  },
  unverifiedText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    flex: 1,
  },
  cacRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  cacLabel: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
  },
  cacValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
});
