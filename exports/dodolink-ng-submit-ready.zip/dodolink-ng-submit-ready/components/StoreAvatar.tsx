import React, { useState } from "react";
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { showAlert } from "@/utils/alerts";
import * as ImagePicker from "expo-image-picker";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useUpdateStore, getListStoresQueryKey, getGetStoreQueryKey, type Store } from "@workspace/api-client-react";
import { uploadImageToStorage, getImageUrl } from "@/utils/storage";
import { useQueryClient } from "@tanstack/react-query";
import { PhotoPreview } from "@/components/PhotoPreview";

interface StoreAvatarProps {
  store: Store;
  size?: number;
  editable?: boolean;
}

export function StoreAvatar({ store, size = 64, editable = false }: StoreAvatarProps) {
  const colors = useColors();
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const [localUri, setLocalUri] = useState<string | null>(null);
  const [previewVisible, setPreviewVisible] = useState(false);

  const updateStore = useUpdateStore({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListStoresQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetStoreQueryKey(store.id) });
      },
    },
  });

  const initial = store.name ? store.name.charAt(0).toUpperCase() : "?";
  const storedUrl = store.imageUrl ? getImageUrl(store.imageUrl) : null;
  const photoUri = localUri ?? storedUrl;

  const handlePress = async () => {
    if (!editable || uploading) return;

    if (Platform.OS !== "web") {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        showAlert(
          "Permission needed",
          "Please allow access to your photo library to set a store photo."
        );
        return;
      }
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.85,
    });

    if (result.canceled || !result.assets[0]) return;

    const asset = result.assets[0];
    setImgError(false);
    setLocalUri(asset.uri);
    setUploading(true);
    try {
      const objectPath = await uploadImageToStorage(asset.uri);
      await updateStore.mutateAsync({ storeId: store.id, data: { imageUrl: objectPath } });
    } catch {
      setLocalUri(null);
      showAlert("Upload failed", "Could not update the store photo. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const radius = size / 2;
  const cameraSize = Math.round(size * 0.32);
  const badgeSize = Math.round(size * 0.38);

  const isVerified = store.verificationStatus === "verified";

  const [imgError, setImgError] = useState(false);

  const avatar = (
    <View style={styles.avatarWrapper}>
      <View
        style={[
          styles.circle,
          { width: size, height: size, borderRadius: radius, backgroundColor: colors.primary },
        ]}
      >
        {photoUri && !imgError ? (
          <Image
            source={{ uri: photoUri }}
            style={[styles.photo, { borderRadius: radius }]}
            onError={() => setImgError(true)}
          />
        ) : (
          <Text style={[styles.initial, { fontSize: size * 0.38, color: colors.primaryForeground }]}>
            {initial}
          </Text>
        )}

        {uploading && (
          <View style={[styles.overlay, { borderRadius: radius }]}>
            <ActivityIndicator color="#fff" size="small" />
          </View>
        )}

        {editable && !uploading && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Change store photo"
            onPress={(event) => { event.stopPropagation(); void handlePress(); }}
            style={[
              styles.badge,
              {
                width: badgeSize,
                height: badgeSize,
                borderRadius: badgeSize / 2,
                backgroundColor: colors.accent,
                bottom: 0,
                right: 0,
              },
            ]}
          >
            <Feather name="camera" size={cameraSize} color="#fff" />
          </Pressable>
        )}
      </View>

      {isVerified && (
        <View style={styles.verifiedChip}>
          <Feather name="check-circle" size={10} color="#fff" />
          <Text style={styles.verifiedText}>Verified</Text>
        </View>
      )}
    </View>
  );

  return (
    <>
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={photoUri && !imgError ? "View store photo" : "Add store photo"}
      onPress={(event) => {
        event.stopPropagation();
        if (photoUri && !imgError) setPreviewVisible(true);
        else if (editable) void handlePress();
      }}
      disabled={uploading || (!editable && (!photoUri || imgError))}
      style={({ pressed }) => [pressed && { opacity: 0.8 }]}
    >
      {avatar}
    </Pressable>
    <PhotoPreview uri={previewVisible ? photoUri : null} onClose={() => setPreviewVisible(false)} />
    </>
  );
}

const styles = StyleSheet.create({
  avatarWrapper: {
    alignItems: "center",
    gap: 4,
  },
  circle: {
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  photo: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  initial: {
    fontFamily: "Inter_700Bold",
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.45)",
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  verifiedChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    backgroundColor: "#1B5E20",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
  },
  verifiedText: {
    color: "#fff",
    fontSize: 10,
    fontFamily: "Inter_600SemiBold",
    fontWeight: "600",
  },
});
