DodoLink NG — standalone Expo project source

The Expo project is at this directory's root. All direct app dependencies are
listed in package.json with concrete versions; the generated API client that was
previously a private workspace dependency is included at lib/api-client-react/.
The pnpm lockfile is included for reproducible dependency resolution.

Validation performed in an isolated copy:
- Expo config prebuild resolved the configured plugin list (11 entries).
- Expo prebuild for iOS completed without installing pods; the Clerk plugin,
  local Podfile patch plugin, and iOS build-number floor plugin all applied.
- The custom build-number plugin produced iOS build version 19.
- The source app's Expo SDK dependency check passed.

Important: EAS Submit uploads an already-built binary; it does not execute Expo
config plugins. Those plugins are applied during Expo prebuild/build. No EAS
submission was run. The Apple App Store Connect private API key, signing keys,
local environment files, generated native projects, and IPA are not included.
The submit profile expects the private API key at .secrets/AuthKey_5B5WP5KMAG.p8;
that file must remain private and is intentionally absent from this archive.
